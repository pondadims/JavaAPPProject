package librarymanagement;

import java.sql.Date;

public class getData {
    
    public static String path;
    public static String studentNumber;
    
    public static String pathImage;
    
    public static String takeBookTitle;
    
//    SAVED DATA
    public static String savedTitle;
    public static String savedAuthor;
    public static String savedGenre;
    public static String savedImage;
    public static Date savedDate;
    
}
